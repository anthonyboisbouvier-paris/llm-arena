# LLM Arena

**Where Language Models Battle for Glory** ⚔️

LLM Arena is an AI model evaluation platform that lets you objectively compare language models through peer-reviewed rankings.

## Features

- 🎯 Side-by-side model comparison
- ⚖️ Multi-judge evaluation system
- 👑 Supreme Court mode with elite judges
- 📊 Borda count ranking methodology
- 🔬 Blind evaluation (anonymized responses)

## How It Works

1. **Challenge** - Enter your prompt
2. **Battle** - Multiple AI models respond
3. **Judgment** - AI judges evaluate all responses
4. **Champion** - Objective ranking emerges

## Live Demo

Visit: [https://anthonyboisbouvier-paris.github.io/llm-arena/](https://anthonyboisbouvier-paris.github.io/llm-arena/)

## Contact

Questions or feedback? Reach out: antho_007@hotmail.fr

Built with ⚔️ for the AI community
